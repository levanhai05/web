package com.example.levanhai3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Levanhai3Application {

	public static void main(String[] args) {
		SpringApplication.run(Levanhai3Application.class, args);
	}

}
